# 第四周与 v0.1 阶段交付 Implementation Plan

> **For agentic workers:** 使用 `superpowers:executing-plans` 按任务执行本计划；步骤使用复选框记录。当前文档是计划，未勾选项均未实施。默认在同一会话执行；分工表表示小组职责，不表示自动启动子代理。
>
> **版本说明：** 本文档第 1～7 节是 2026-09-30 的实施计划原文（计划口径为 9 个视图、Q01～Q08、C01～C11、R01～R13、两个空库）。第 8 节是 2026-09-30 的执行记录，**第 9 节是 2026-10-01 v0.1 修订记录**，修订后的交付口径以第 9 节、根 `README.md` 和 `report/stage_report.md` 为准。

**Goal:** 按《第四周任务讲解.docx》完成连接查询、统计视图、完整性与角色权限，并交付可从空库复现、附真实验证证据的 API Token 中转站数据库原型 v0.1。

**Architecture:** 保留第三周成果作为数据基线，将其四个基础脚本转换为根目录 `sql/` 下可指定数据库名的阶段脚本；新增 `query.sql`、`view.sql`、`constraint.sql`、`role.sql`。使用独立实验库、自动断言、两个空库的数据签名比对和 SSMS 现场截图验收，统一根目录 README 为阶段复现入口。

**Tech Stack:** Windows PowerShell、SQL Server 2025 Express、SSMS、ODBC sqlcmd、Python 3.11+ 标准库、T-SQL。

---

## 1. 执行依据与当前状态

- 任务书：`D:\Desktop\DB\week4\第四周任务讲解.docx`。
- 仓库根目录：`D:\Desktop\DB\DB_lab`。以下相对路径均从此目录起算。
- 规划日期：2026-09-30；本次检查的最新提交为 `0d4839f`。
- 已有第三周六个 SQL 脚本、14 张业务表、样例生成器和演示资料；第四周尚未实施。
- 已读取真实 DDL。主键、外键、候选码、状态枚举等已有约束，第四周应盘点并补充，不重复创建。
- 已在内存中运行现有生成器的 `self_check()`，并确认 `build_sql()` 与仓库中的 `02_insert_data.sql` 文本完全相同；未执行生成器的写文件入口。
- 当前样例 SQL 的 SHA256：`63011c8ae790a3b5dc33eed2a1a67e995f9bff68b86452e39a2755f14315b7ed`。
- 本次仅验证了本机可以找到 Python 和 sqlcmd；没有验证 SQL Server 服务、连接权限或任何新增 SQL 的执行结果。
- 工作区已有未跟踪的 `week3/sql/.vs/`、`week3/注释版/`，实施时保留，不混入阶段提交。
- README 与 DEMO_GUIDE 中部分相对链接、目录图仍为整理文件前的路径，列入本次文档修正。

本次采用“复用第三周基线，补齐第四周能力”的方案。直接在 `TokenHubDB_Week3` 上开发容易混淆历史成果；全面重构模式会扩大课程任务。因此新建 `TokenHubDB_v01_A`、`TokenHubDB_v01_B` 两个独立实验库，第三周库继续作为历史材料。

## 2. 课程要求到交付物的对应关系

| 任务书要求 | 实施任务 | 交付物 | 可判定的通过标准 |
|---|---|---|---|
| 多表连接、聚合、HAVING、子查询 | T3 | `sql/query.sql` | 8 个有业务含义的查询，覆盖 INNER/LEFT JOIN、GROUP BY、HAVING、NOT EXISTS |
| 创建并查询不同统计视图 | T4 | `sql/view.sql` | 4 个业务视图及 5 个权限用途视图，业务视图结果与独立 SQL 一致 |
| 主外键、UNIQUE、CHECK、DEFAULT、NULL | T5 | `sql/constraint.sql` | 输出约束盘点；新增 3 个跨列 CHECK；合法与非法用例均断言成功 |
| 根据角色授予最小权限 | T6 | `sql/role.sql` | 4 种角色、5 个演示用户；正常访问成功、禁止操作得到预期权限错误、会员数据相互隔离 |
| 从空库复现 | T1、T2、T7 | `tools/prepare_v01.ps1`、`tools/run_v01.ps1`、`sql/verify.sql`、`sql/signature.sql` | 两个空库完整运行退出码均为 0；14 张表的数据签名逐表一致 |
| README 包含范围、角色、流程、执行顺序 | T8 | `README.md`、`DEMO_GUIDE.md` | 新成员仅按 README 即可完成复现；全部本地链接存在 |
| 建库、CRUD、查询、视图、非法、越权截图 | T8 | `result/` | 12 类截图及原始日志，文件可定位到脚本与用例编号 |
| 设计思路、实验过程、实验总结 | T8 | `week4/stage_report.md` | 解释模式、键、约束、权限和正反例；明确实际结果与局限 |
| AI 日志、组内分工 | T8 | `week4/ai_usage_log.md`、`week4/team_division.md` | 记录实际建议、实际人工修改、验证人员和证据，未复核不写成已复核 |
| 之前每周任务也要包含 | T8、T9 | 阶段交付索引与完整仓库 | 第一、二周设计，第三周脚本与演示，第四周成果都有入口 |

## 3. 统一业务口径

1. **销售额与销量**：仅统计 `Orders.status = 'paid'`。pending、cancelled、refunded 均排除。销售额使用下单快照 `OrderDetails.subtotal`，不使用商品当前价格重算历史交易；销量分别标明套餐件数和 Token 数。
2. **订单粒度**：订单明细视图一行对应一个 `detail_id`。订单金额不能在一对多连接后再次直接求和；会员消费统计从 Orders 聚合，商品销售统计从 OrderDetails 聚合。
3. **余额**：按用户和 provider 管理；当前样例已支付购入 Token 减使用量等于余额。退款订单在该合成数据中未形成净充值。
4. **库存**：Inventory 与 UpstreamAccount 一对一，表示上游账号可用额度。`current_quota = total_quota - used_quota = SUM(InventoryLog.change_amount)`。
5. **补货**：有效账号指 `status = 'active'` 且未过期；低库存指 `current_quota < safety_threshold`。暂停、过期、耗尽账号单独显示状态，不能直接当作可用供给。
6. **固定时点**：库存状态视图使用样例快照时点 `2026-09-22T23:59:59`，输出 `as_of_time`，避免演示日期变化导致验收漂移。报告注明这是样例快照判断，不是实时监控。
7. **使用汇总**：daily、weekly、monthly 是同一批调用的三种聚合粒度。跨粒度相加会重复统计；每种粒度分别与原始日志核对。
8. **权限**：`dbo.Roles` 是应用层角色数据；SQL Server 的数据库角色是实际授权机制，二者分别说明。
9. **会员隔离**：数据库用户 `hub_user_1` 对应业务用户 1，`hub_user_2` 对应业务用户 2；个人视图按 `USER_NAME()` 过滤。不向会员开放全表 SELECT，也不使用可由调用者任意设置的 SESSION_CONTEXT 作为身份依据。
10. **阶段范围**：会员本周演示商品浏览、个人订单、余额和用量查询；店员演示待处理订单的取消/恢复待处理。真实注册、支付、退款、充值与补货事务、应用登录映射留在后续阶段。店员不能通过直接改状态执行支付或退款。

## 4. 固定数据基准

以下数字来自现有生成器及样例 SQL，实施时必须再经 SQL Server 查询验证。

| 表 | 行数 | 表 | 行数 |
|---|---:|---|---:|
| Roles | 3 | Users | 40 |
| Products | 10 | UpstreamAccount | 8 |
| Inventory | 8 | Employees | 6 |
| Orders | 100 | OrderDetails | 184 |
| InventoryLog | 3012 | TokenBalances | 61 |
| TokenUsageLogs | 3000 | UsageSummary | 3394 |
| RestockTask | 8 | ExceptionLog | 15 |

| 指标 | 预期 |
|---|---:|
| 全部订单金额 / Token | 4931.00 / 108950000 |
| 已支付订单数 / 销售额 / Token | 85 / 4228.90 / 92950000 |
| 已支付明细数 / 套餐件数 | 158 / 191 |
| 使用 Token / 上游消耗 | 6040100 / 7248120 |
| 用户余额合计 | 86909900 |
| 库存合计 / 库存流水净额 | 6350000 / 6350000 |
| 每种汇总粒度的 Token / 请求数 | 6040100 / 3000 |
| 没有已支付订单的用户数 | 14 |
| 消费达到 100 元的用户数 | 13 |
| 用户 1 / 用户 2 的全部订单数 | 13 / 15 |
| 当前有效且低于安全阈值的账号数 | 0 |

无已支付订单的用户 ID 应为 `9,16,19,22,23,25,28,29,31,36,37,38,39,40`。达到 100 元的用户 ID 应为 `1,2,3,5,8,11,12,15,17,18,24,33,35`。

## 5. 目标文件结构与依赖顺序

```text
DB_lab/
├── README.md                         # v0.1 入口，更新
├── DEMO_GUIDE.md                     # 课堂演示与证据位置，更新
├── requirements.txt                  # 沿用，无新增运行依赖
├── sql/                             # 新建，完整阶段 SQL
│   ├── 00_create_database.sql        # 第三周脚本转换产物
│   ├── 01_create_tables.sql          # 第三周脚本转换产物
│   ├── 02_insert_data.sql            # 第三周脚本转换产物
│   ├── 03_crud_demo.sql              # 第三周脚本转换产物
│   ├── query.sql                    # 8 项查询
│   ├── view.sql                     # 9 个视图及展示查询
│   ├── constraint.sql               # 盘点、补充、正反例
│   ├── role.sql                     # 角色、授权、正反例
│   ├── verify.sql                   # 综合验收断言
│   └── signature.sql                # 14 张表逐表内容签名
├── tools/
│   ├── prepare_v01.ps1              # 将四个基础脚本转换到 sql/
│   └── run_v01.ps1                  # 顺序执行、遇非预期错误停止、留日志
├── result/
│   ├── README.md                    # 证据索引
│   ├── run_A/                       # 首次空库日志与签名
│   ├── run_B/                       # 第二次空库日志与签名
│   ├── dev/                         # 分步开发验证日志
│   ├── repeat_A/                    # 第四周脚本重复执行日志
│   └── screenshots/                 # 实际 SSMS 截图
├── week4/
│   ├── week4_deliverables.md         # 验收清单与结论
│   ├── stage_report.md              # 第一阶段完整报告
│   ├── ai_usage_log.md
│   └── team_division.md
├── week1 & 2/                       # 保留并链接
├── week3/                           # 保留并链接
└── docs/superpowers/plans/           # 本计划
```

执行依赖：`T1 基础材料 → T2 验收契约 → T3 查询 → T4 视图 → T5 约束 → T6 权限 → T7 双空库验收 → T8 文档与证据 → T9 交付核对`。

SQL 正式执行顺序：`00 → 01 → 02 → 03 → query → view → constraint → role → verify → signature`。第三周 `04_constraint_demo.sql` 保留作历史演示，不进入新流水线，因为其中的预期错误没有捕获；新 `constraint.sql` 承担完整验证。

## T1 环境核对与阶段基础脚本

**文件：** 创建 `tools/prepare_v01.ps1` 和 `sql/00_create_database.sql` 至 `sql/03_crud_demo.sql`。

- [ ] 从仓库根目录运行以下只读检查，记录实例版本和当前数据库列表。

```powershell
Set-Location 'D:\Desktop\DB\DB_lab'
git status --short
python --version
Get-Command sqlcmd
sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -Q "SELECT @@VERSION; SELECT name FROM sys.databases ORDER BY name;"
```

预期：Python ≥ 3.11；sqlcmd 可用；连接成功。若实例名不符，核对本机 SQL Server 服务后统一修改命令中的 `-Server`，不盲目创建第二个 SQL Server 实例。

- [ ] 创建下面的 `tools/prepare_v01.ps1`。四个基础脚本的源文件固定为第三周原文件；以后修改数据基线时先改源文件并重新生成，禁止分别维护两套相同逻辑。

```powershell
$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$targetDir = Join-Path $repoRoot 'sql'
New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
$names = @('00_create_database.sql', '01_create_tables.sql',
           '02_insert_data.sql', '03_crud_demo.sql')
$utf8 = New-Object System.Text.UTF8Encoding($false)
foreach ($name in $names) {
    $source = Join-Path $repoRoot "week3/sql/$name"
    $content = [System.IO.File]::ReadAllText($source)
    if (-not $content.Contains('TokenHubDB_Week3')) {
        throw "Source does not contain expected database name: $source"
    }
    $converted = $content.Replace('TokenHubDB_Week3', '$(DatabaseName)')
    [System.IO.File]::WriteAllText((Join-Path $targetDir $name), $converted, $utf8)
    Write-Output "PREPARED $name"
}
```

- [ ] 执行转换；检查四份文件均含 SQLCMD 变量，确认转换未改动第三周脚本。

```powershell
powershell -NoProfile -File .\tools\prepare_v01.ps1
rg -n 'TokenHubDB_Week3|\$\(DatabaseName\)' .\sql
git diff -- week3
```

预期：四条 PREPARED；目标数据库引用均为 `$(DatabaseName)`；第三周无新增差异。SSMS 执行这些文件需要打开“查询 → SQLCMD 模式”，在编辑窗口临时提供 `:setvar DatabaseName "TokenHubDB_v01_A"`；不把固定 `:setvar` 写入正式脚本覆盖命令行参数。

- [ ] 每个新建 SQL 文件开头使用以下共同头部，signature.sql 按 T7 的独立规则处理。

```sql
USE [$(DatabaseName)];
GO
SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO
```

- [ ] 为分步开发单独创建 `TokenHubDB_v01_Dev`，避免占用正式 A/B 验收库。若名称已存在，选择新的 Dev 后缀并同步替换后续分步命令。

```powershell
New-Item -ItemType Directory -Path .\result\dev -Force | Out-Null
foreach ($name in @('00_create_database.sql','01_create_tables.sql','02_insert_data.sql','03_crud_demo.sql')) {
    sqlcmd -S 'localhost\SQLEXPRESS' -d master -E -C -b -f 65001 -u `
      -v 'DatabaseName=TokenHubDB_v01_Dev' -i ".\sql\$name" -o ".\result\dev\$name.log"
    if ($LASTEXITCODE -ne 0) { throw "Baseline failed: $name" }
}
```

**完成标准：** 四份基础文件可按顺序创建一个新库并装载原始 14 表；目标库若已存在，00 脚本报错停止，不自动删除或清空。

## T2 先固定验收契约

**文件：** 创建 `sql/verify.sql`，后续 T7 补齐结果比对与签名。

- [ ] 把第 4 节的表行数、关键指标和下列断言写入 verify.sql。对缺少视图的断言使用动态 SQL，使失败信息明确。
- [ ] 基础装载后先运行验收，确认尚未创建视图时返回 `Missing v_ProductSales`；完成 T4 后再次运行，应通过对应检查。

```sql
IF (SELECT COUNT(*) FROM sys.tables WHERE is_ms_shipped = 0) <> 14
    THROW 51001, N'Expected 14 business tables', 1;
IF (SELECT COUNT(*) FROM dbo.Orders WHERE status='paid') <> 85
    THROW 51002, N'Paid order count mismatch', 1;
IF (SELECT SUM(total_amount) FROM dbo.Orders WHERE status='paid') <> 4228.90
    THROW 51003, N'Paid revenue mismatch', 1;
IF (SELECT SUM(remaining_tokens) FROM dbo.TokenBalances) <> 86909900
    THROW 51004, N'Balance total mismatch', 1;
IF OBJECT_ID(N'dbo.v_ProductSales', N'V') IS NULL
    THROW 51005, N'Missing v_ProductSales', 1;
EXEC sys.sp_executesql N'
IF (SELECT COUNT(*) FROM dbo.v_ProductSales) <> 10
    THROW 51006, N''Product view row count mismatch'', 1;';
```

**验收不是只看“有返回结果”**：应由 `IF ... THROW` 使失败变成非零退出码；每一项成功用带用例编号的 SELECT 或 PRINT 留下可定位标记。

```powershell
sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -f 65001 `
  -v 'DatabaseName=TokenHubDB_v01_Dev' -i .\sql\verify.sql
```

此时预期非零退出码且消息为 `Missing v_ProductSales`；只有这一预期失败说明验收契约确实覆盖尚未实现的视图。

## T3 多表与统计查询

**文件：** 创建 `sql/query.sql`。加入共同头部后，按编号加入以下查询；每段前输出 Q01～Q08 标签。

- [ ] Q01 查询订单详情，验证一行对应一条明细，基础数据应为 184 行。

```sql
PRINT N'Q01 Order details';
SELECT o.order_id, o.user_id, u.username, o.status, o.created_at,
       d.detail_id, p.product_id, p.name AS product_name,
       d.quantity, d.unit_price, d.subtotal, d.total_tokens
FROM dbo.Orders o
JOIN dbo.Users u ON u.user_id=o.user_id
JOIN dbo.OrderDetails d ON d.order_id=o.order_id
JOIN dbo.Products p ON p.product_id=d.product_id
ORDER BY o.order_id, d.detail_id;
```

- [ ] Q02 统计各商品已支付销量，保留没有销量的商品。10 行，总件数 191，总销售额 4228.90。

```sql
PRINT N'Q02 Paid product sales';
WITH s AS (
    SELECT d.product_id, SUM(CAST(d.quantity AS BIGINT)) AS units_sold,
           SUM(d.subtotal) AS revenue, SUM(d.total_tokens) AS tokens_sold
    FROM dbo.OrderDetails d JOIN dbo.Orders o ON o.order_id=d.order_id
    WHERE o.status='paid' GROUP BY d.product_id
)
SELECT p.product_id, p.name, p.model_provider,
       COALESCE(s.units_sold,0) AS units_sold,
       COALESCE(s.revenue,0) AS revenue, COALESCE(s.tokens_sold,0) AS tokens_sold
FROM dbo.Products p LEFT JOIN s ON s.product_id=p.product_id
ORDER BY revenue DESC, p.product_id;
```

- [ ] Q03 统计全部会员消费，LEFT JOIN 的 paid 条件写在 ON 中。40 行，其中 14 人金额为 0。

```sql
PRINT N'Q03 All member spending';
SELECT u.user_id,u.username,COUNT(o.order_id) AS paid_orders,
       COALESCE(SUM(o.total_amount),0) AS paid_amount
FROM dbo.Users u
LEFT JOIN dbo.Orders o ON o.user_id=u.user_id AND o.status='paid'
GROUP BY u.user_id,u.username ORDER BY u.user_id;
```

- [ ] Q04 使用 HAVING 找出消费达到 100 元的会员，预期 13 人，ID 与第 4 节一致。

```sql
PRINT N'Q04 Members spending at least 100';
SELECT u.user_id,u.username,SUM(o.total_amount) AS paid_amount
FROM dbo.Users u JOIN dbo.Orders o ON o.user_id=u.user_id
WHERE o.status='paid'
GROUP BY u.user_id,u.username HAVING SUM(o.total_amount)>=100
ORDER BY paid_amount DESC,u.user_id;
```

- [ ] Q05 使用 NOT EXISTS 找出从未产生已支付订单的会员，预期 14 人。

```sql
PRINT N'Q05 Members without paid orders';
SELECT u.user_id,u.username FROM dbo.Users u
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.Orders o WHERE o.user_id=u.user_id AND o.status='paid'
) ORDER BY u.user_id;
```

- [ ] Q06 查找有效低库存账号。基础数据预期 0 行；T7 会注入临时低库存记录验证正例。

```sql
PRINT N'Q06 Active low quota accounts at sample snapshot';
DECLARE @as_of DATETIME2(0)='2026-09-22T23:59:59';
SELECT a.account_id,a.provider,a.account_name,i.current_quota,a.safety_threshold
FROM dbo.UpstreamAccount a JOIN dbo.Inventory i ON i.account_id=a.account_id
WHERE a.status='active' AND (a.expires_at IS NULL OR a.expires_at>@as_of)
  AND i.current_quota<a.safety_threshold
ORDER BY a.account_id;
```

- [ ] Q07 按 provider 汇总调用量和上游消耗；汇总请求数 3000，Token 与第 4 节一致。

```sql
PRINT N'Q07 Usage by provider';
SELECT p.model_provider,COUNT_BIG(*) AS requests,
       SUM(CAST(l.tokens_used AS BIGINT)) AS tokens_used,
       SUM(CAST(l.upstream_tokens_consumed AS BIGINT)) AS upstream_used
FROM dbo.TokenUsageLogs l JOIN dbo.Products p ON p.product_id=l.product_id
GROUP BY p.model_provider ORDER BY p.model_provider;
```

- [ ] Q08 连接补货任务、账号及创建/执行员工。执行员工用 LEFT JOIN，保留未分配任务，预期 8 行。

```sql
PRINT N'Q08 Restock task assignment';
SELECT t.task_id,a.account_name,t.status,t.target_amount,t.actual_amount,
       creator.name AS created_by_name,assignee.name AS assigned_to_name
FROM dbo.RestockTask t
JOIN dbo.UpstreamAccount a ON a.account_id=t.account_id
JOIN dbo.Employees creator ON creator.employee_id=t.created_by
LEFT JOIN dbo.Employees assignee ON assignee.employee_id=t.assigned_to
ORDER BY t.task_id;
```

**完成标准：** 8 个查询均执行成功；报告能解释 Q02、Q03、Q08 为何使用 LEFT JOIN，Q05 为何使用 NOT EXISTS，Q01 为什么不能直接 SUM 订单总金额。

```powershell
sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -f 65001 -u `
  -v 'DatabaseName=TokenHubDB_v01_Dev' -i .\sql\query.sql -o .\result\dev\query.sql.log
if ($LASTEXITCODE -ne 0) { throw 'Query verification failed' }
```

## T4 统计视图与权限用途视图

**文件：** 创建 `sql/view.sql`。每个 `CREATE OR ALTER VIEW` 单独一个 GO 批次；视图中不加入 ORDER BY，展示查询自行排序。

- [ ] 创建 4 个业务视图。

```sql
CREATE OR ALTER VIEW dbo.v_OrderDetail AS
SELECT o.order_id,o.user_id,u.username,o.status,o.created_at,o.paid_at,
       d.detail_id,p.product_id,p.name AS product_name,p.model_provider,
       d.quantity,d.unit_price,d.subtotal,d.total_tokens
FROM dbo.Orders o JOIN dbo.Users u ON u.user_id=o.user_id
JOIN dbo.OrderDetails d ON d.order_id=o.order_id
JOIN dbo.Products p ON p.product_id=d.product_id;
GO
CREATE OR ALTER VIEW dbo.v_ProductSales AS
WITH s AS (
    SELECT d.product_id,SUM(CAST(d.quantity AS BIGINT)) AS units_sold,
           SUM(d.subtotal) AS revenue,SUM(d.total_tokens) AS tokens_sold
    FROM dbo.OrderDetails d JOIN dbo.Orders o ON o.order_id=d.order_id
    WHERE o.status='paid' GROUP BY d.product_id
)
SELECT p.product_id,p.name,p.model_provider,
       COALESCE(s.units_sold,0) AS units_sold,
       COALESCE(s.revenue,0) AS revenue,COALESCE(s.tokens_sold,0) AS tokens_sold
FROM dbo.Products p LEFT JOIN s ON s.product_id=p.product_id;
GO
CREATE OR ALTER VIEW dbo.v_MemberSpending AS
SELECT u.user_id,u.username,COUNT(o.order_id) AS paid_orders,
       COALESCE(SUM(o.total_amount),0) AS paid_amount,
       COALESCE(SUM(o.total_tokens),0) AS paid_tokens
FROM dbo.Users u LEFT JOIN dbo.Orders o
  ON o.user_id=u.user_id AND o.status='paid'
GROUP BY u.user_id,u.username;
GO
CREATE OR ALTER VIEW dbo.v_InventoryStatus AS
SELECT a.account_id,a.provider,a.account_name,a.status,
       i.current_quota,a.safety_threshold,a.expires_at,
       CAST('2026-09-22T23:59:59' AS DATETIME2(0)) AS as_of_time,
       CASE WHEN a.status<>'active' THEN a.status
            WHEN a.expires_at<='2026-09-22T23:59:59' THEN 'expired'
            WHEN i.current_quota<a.safety_threshold THEN 'low'
            ELSE 'normal' END AS stock_state
FROM dbo.UpstreamAccount a JOIN dbo.Inventory i ON i.account_id=a.account_id;
GO
```

- [ ] 创建 5 个权限用途视图。个人视图保留业务 user_id 以便核对；不包含 password_hash、api_key。待处理订单视图的 CHECK OPTION 阻止店员把可见行改成 paid/refunded。

```sql
CREATE OR ALTER VIEW dbo.v_ProductCatalog AS
SELECT product_id,name,description,price,model_provider,token_amount
FROM dbo.Products WHERE status='active';
GO
CREATE OR ALTER VIEW dbo.v_MyOrders AS
SELECT order_id,user_id,total_amount,total_tokens,status,created_at,paid_at
FROM dbo.Orders
WHERE USER_NAME()=CONCAT(N'hub_user_',CONVERT(NVARCHAR(11),user_id));
GO
CREATE OR ALTER VIEW dbo.v_MyBalances AS
SELECT balance_id,user_id,model_provider,remaining_tokens,updated_at
FROM dbo.TokenBalances
WHERE USER_NAME()=CONCAT(N'hub_user_',CONVERT(NVARCHAR(11),user_id));
GO
CREATE OR ALTER VIEW dbo.v_MyUsage AS
SELECT log_id,user_id,product_id,tokens_used,api_endpoint,used_at
FROM dbo.TokenUsageLogs
WHERE USER_NAME()=CONCAT(N'hub_user_',CONVERT(NVARCHAR(11),user_id));
GO
CREATE OR ALTER VIEW dbo.v_StaffOrderQueue AS
SELECT order_id,user_id,status,created_at
FROM dbo.Orders WHERE status IN ('pending','cancelled')
WITH CHECK OPTION;
GO
SELECT * FROM dbo.v_OrderDetail ORDER BY order_id,detail_id;
SELECT * FROM dbo.v_ProductSales ORDER BY product_id;
SELECT * FROM dbo.v_MemberSpending ORDER BY user_id;
SELECT * FROM dbo.v_InventoryStatus ORDER BY account_id;
```

**完成标准：** `sys.views` 中恰有以上 9 个业务视图；4 个核心视图行数分别为 184、10、40、8；按 T7 验证总额与基表一致。重复执行 view.sql 成功。

```powershell
foreach ($name in @('view.sql','verify.sql')) {
    sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -f 65001 -u `
      -v 'DatabaseName=TokenHubDB_v01_Dev' -i ".\sql\$name" -o ".\result\dev\$name.log"
    if ($LASTEXITCODE -ne 0) { throw "View stage failed: $name" }
}
```

此时 verify.sql 仅包含 T2 的初始断言；T7 的完整断言在 T6 完成后加入。

## T5 完整性约束与正反例

**文件：** 创建 `sql/constraint.sql`。

- [ ] 首先输出主键/UNIQUE、外键、CHECK、DEFAULT、空值属性的盘点，用于报告和截图。

```sql
SELECT OBJECT_NAME(parent_object_id) AS table_name,name,type_desc
FROM sys.key_constraints ORDER BY table_name,name;
SELECT OBJECT_NAME(parent_object_id) AS table_name,name,is_disabled,is_not_trusted
FROM sys.foreign_keys ORDER BY table_name,name;
SELECT OBJECT_NAME(parent_object_id) AS table_name,name,definition,is_disabled,is_not_trusted
FROM sys.check_constraints ORDER BY table_name,name;
SELECT OBJECT_NAME(parent_object_id) AS table_name,name,definition
FROM sys.default_constraints ORDER BY table_name,name;
SELECT OBJECT_NAME(c.object_id) AS table_name,c.name,c.is_nullable
FROM sys.columns c JOIN sys.tables t ON t.object_id=c.object_id
ORDER BY table_name,c.column_id;
```

- [ ] 使用 `WITH CHECK ADD` 新增以下 3 个约束。先按名称检查是否存在，支持重复执行；已有数据不满足时停止并调查，禁止通过 NOCHECK 绕过。

```sql
IF OBJECT_ID(N'dbo.CK_OrderDetails_subtotal_formula',N'C') IS NULL
    ALTER TABLE dbo.OrderDetails WITH CHECK ADD
    CONSTRAINT CK_OrderDetails_subtotal_formula
    CHECK (subtotal=CONVERT(DECIMAL(19,2),quantity)*unit_price);
IF OBJECT_ID(N'dbo.CK_OrderDetails_tokens_formula',N'C') IS NULL
    ALTER TABLE dbo.OrderDetails WITH CHECK ADD
    CONSTRAINT CK_OrderDetails_tokens_formula
    CHECK (total_tokens=CAST(quantity AS BIGINT)*tokens_per_unit);
IF OBJECT_ID(N'dbo.CK_Orders_payment_time',N'C') IS NULL
    ALTER TABLE dbo.Orders WITH CHECK ADD CONSTRAINT CK_Orders_payment_time
    CHECK (
      (status IN ('paid','refunded') AND paid_at IS NOT NULL AND paid_at>=created_at)
      OR (status IN ('pending','cancelled') AND paid_at IS NULL)
    );
GO
```

不把订单总额与明细之和、账号与库存与流水一致性写成普通 CHECK：这些是跨表规则，本周使用独立查询验证，后续阶段由业务事务维护。多态 `reference_id` 也不能直接设成同时指向多张表的外键。

- [ ] 实现用例驱动器：把下表 SQL 放入 `#ConstraintCases`，每行分别执行；合法用例执行成功再回滚，非法用例捕获指定错误号及约束名再判定通过。

| ID | SQL（作为完整批次执行） | 预期 |
|---|---|---|
| C01 | `INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens) VALUES(N'W4默认值验证',1,'Other',900001,900001); IF NOT EXISTS(SELECT 1 FROM dbo.Products WHERE name=N'W4默认值验证' AND status='active' AND created_at IS NOT NULL AND description IS NULL) THROW 51101,N'Default assertion failed',1;` | 成功；验证 DEFAULT 与可空字段 |
| C02 | `INSERT dbo.Orders(user_id,total_amount,total_tokens) VALUES(1,0,0);` | 成功；pending 默认值；允许尚未填写明细的待处理订单 |
| C03 | `SET IDENTITY_INSERT dbo.Orders ON; INSERT dbo.Orders(order_id,user_id,total_amount,total_tokens) VALUES(1,1,0,0);` | 2627，`PK_Orders`；清理 `SET IDENTITY_INSERT dbo.Orders OFF;` |
| C04 | `INSERT dbo.Users(username,password_hash,email) VALUES('user001',REPLICATE('x',60),'w4-unique@example.edu');` | 2627，`UQ_Users_username` |
| C05 | `INSERT dbo.Orders(user_id,total_amount,total_tokens) VALUES(999999,0,0);` | 547，`FK_Orders_Users` |
| C06 | `INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens) VALUES(N'W4负价格',-1,'Other',900002,900002);` | 547，`CK_Products_price` |
| C07 | `INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens) VALUES(NULL,1,'Other',900003,900003);` | 515；NOT NULL |
| C08 | `UPDATE dbo.OrderDetails SET subtotal=subtotal+0.01 WHERE detail_id=1;` | 547，`CK_OrderDetails_subtotal_formula` |
| C09 | `UPDATE dbo.OrderDetails SET total_tokens=total_tokens+1 WHERE detail_id=1;` | 547，`CK_OrderDetails_tokens_formula` |
| C10 | `UPDATE dbo.Orders SET paid_at=NULL WHERE order_id=(SELECT MIN(order_id) FROM dbo.Orders WHERE status='paid');` | 547，`CK_Orders_payment_time` |
| C11 | `DELETE dbo.Users WHERE user_id=1;` | 547；引用该用户的外键，具体 FK 名可因执行计划不同而变化 |

驱动器采用以下完整控制逻辑。将表格中的 SQL 转义单引号后作为 `statement_sql` 插入；合法用例 expected_error=0；无须限定名称的用例 expected_name=NULL；除 C03 外 cleanup_sql=N''。

```sql
SET XACT_ABORT ON;
CREATE TABLE #ConstraintCases (
    case_id VARCHAR(4) PRIMARY KEY, statement_sql NVARCHAR(MAX) NOT NULL,
    expected_error INT NOT NULL, expected_name SYSNAME NULL,
    cleanup_sql NVARCHAR(MAX) NOT NULL
);
INSERT #ConstraintCases VALUES
('C01',N'INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens) VALUES(N''W4默认值验证'',1,''Other'',900001,900001); IF NOT EXISTS(SELECT 1 FROM dbo.Products WHERE name=N''W4默认值验证'' AND status=''active'' AND created_at IS NOT NULL AND description IS NULL) THROW 51101,N''Default assertion failed'',1;',0,NULL,N''),
('C02',N'INSERT dbo.Orders(user_id,total_amount,total_tokens) VALUES(1,0,0); DECLARE @new_id INT=SCOPE_IDENTITY(); IF NOT EXISTS(SELECT 1 FROM dbo.Orders WHERE order_id=@new_id AND status=''pending'' AND paid_at IS NULL) THROW 51102,N''Order default assertion failed'',1;',0,NULL,N''),
('C03',N'SET IDENTITY_INSERT dbo.Orders ON; INSERT dbo.Orders(order_id,user_id,total_amount,total_tokens) VALUES(1,1,0,0);',2627,N'PK_Orders',N'SET IDENTITY_INSERT dbo.Orders OFF;'),
('C04',N'INSERT dbo.Users(username,password_hash,email) VALUES(''user001'',REPLICATE(''x'',60),''w4-unique@example.edu'');',2627,N'UQ_Users_username',N''),
('C05',N'INSERT dbo.Orders(user_id,total_amount,total_tokens) VALUES(999999,0,0);',547,N'FK_Orders_Users',N''),
('C06',N'INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens) VALUES(N''W4负价格'',-1,''Other'',900002,900002);',547,N'CK_Products_price',N''),
('C07',N'INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens) VALUES(NULL,1,''Other'',900003,900003);',515,NULL,N''),
('C08',N'UPDATE dbo.OrderDetails SET subtotal=subtotal+0.01 WHERE detail_id=1;',547,N'CK_OrderDetails_subtotal_formula',N''),
('C09',N'UPDATE dbo.OrderDetails SET total_tokens=total_tokens+1 WHERE detail_id=1;',547,N'CK_OrderDetails_tokens_formula',N''),
('C10',N'UPDATE dbo.Orders SET paid_at=NULL WHERE order_id=(SELECT MIN(order_id) FROM dbo.Orders WHERE status=''paid'');',547,N'CK_Orders_payment_time',N''),
('C11',N'DELETE dbo.Users WHERE user_id=1;',547,NULL,N'');
DECLARE @id VARCHAR(4),@stmt NVARCHAR(MAX),@want INT,@name SYSNAME,
        @cleanup NVARCHAR(MAX),@got INT,@msg NVARCHAR(4000);
DECLARE cases CURSOR LOCAL FAST_FORWARD FOR
SELECT case_id,statement_sql,expected_error,expected_name,cleanup_sql
FROM #ConstraintCases ORDER BY case_id;
OPEN cases;
FETCH NEXT FROM cases INTO @id,@stmt,@want,@name,@cleanup;
WHILE @@FETCH_STATUS=0
BEGIN
    SELECT @got=0,@msg=N'';
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC sys.sp_executesql @stmt;
        ROLLBACK TRANSACTION;
    END TRY
    BEGIN CATCH
        SELECT @got=ERROR_NUMBER(),@msg=ERROR_MESSAGE();
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    END CATCH;
    EXEC sys.sp_executesql @cleanup;
    IF @got<>@want OR (@name IS NOT NULL AND CHARINDEX(@name,@msg)=0)
    BEGIN
        SET @msg=CONCAT(@id,N' failed; expected=',@want,N'; actual=',@got,N'; ',@msg);
        THROW 51199,@msg,1;
    END;
    SELECT @id AS case_id,N'PASS' AS result,@got AS actual_error,@msg AS actual_message;
    FETCH NEXT FROM cases INTO @id,@stmt,@want,@name,@cleanup;
END;
CLOSE cases;
DEALLOCATE cases;
DROP TABLE #ConstraintCases;
```

- [ ] 验证恰有 11 条 PASS；C03 后会话可以正常执行不带 IDENTITY_INSERT 的 INSERT；最终 `@@TRANCOUNT=0`。
- [ ] 记录“回滚恢复表内数据，但 IDENTITY 计数可能前进”；复现一致性比较表内固定数据，不比较当前 identity 计数器。

**完成标准：** 3 个新增约束可信且启用；C01～C11 全部通过；没有遗留测试行。脚本不以“捕获了任意错误”作为通过依据。

```powershell
sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -f 65001 -u `
  -v 'DatabaseName=TokenHubDB_v01_Dev' -i .\sql\constraint.sql -o .\result\dev\constraint.sql.log
if ($LASTEXITCODE -ne 0) { throw 'Constraint verification failed' }
```

## T6 数据库角色、授权与越权演示

**文件：** 创建 `sql/role.sql`。

### 权限矩阵

| 操作 | hub_manager | hub_staff | hub_customer | hub_guest |
|---|---|---|---|---|
| 在售商品目录 | 允许 | 允许 | 允许 | 允许 |
| 全部订单详情与经营统计 | 允许 | 允许 | 禁止 | 禁止 |
| 修改商品价格 | 允许 | 禁止 | 禁止 | 禁止 |
| 待处理订单 pending/cancelled 切换 | 允许 | 仅通过工作队列视图修改 status | 禁止 | 禁止 |
| 个人订单、余额、用量 | 管理员可查基表 | 无个人视图授权 | 仅本人 | 禁止 |
| 基表业务数据 CRUD | 明确授予 14 表 | 禁止 | 禁止 | 禁止 |
| 用户密码哈希、上游密钥 | 仅管理员业务权限范围 | 禁止 | 禁止 | 禁止 |
| 建表、改表、创建登录、授权 | 禁止 | 禁止 | 禁止 | 禁止 |

管理员在此指业务店长，不是 SQL Server DBA；不授予 sysadmin、db_owner、db_datareader、db_datawriter、CONTROL 或 WITH GRANT OPTION。WITHOUT LOGIN 用户用于本地数据库内演示，不代表已经实现应用登录系统。

- [ ] 创建数据库角色和演示用户，创建前用 `DATABASE_PRINCIPAL_ID` 判重；角色成员关系用 `sys.database_role_members` 判重。

```sql
IF DATABASE_PRINCIPAL_ID(N'hub_manager') IS NULL CREATE ROLE hub_manager AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'hub_staff') IS NULL CREATE ROLE hub_staff AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'hub_customer') IS NULL CREATE ROLE hub_customer AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'hub_guest') IS NULL CREATE ROLE hub_guest AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'hub_manager_demo') IS NULL CREATE USER hub_manager_demo WITHOUT LOGIN;
IF DATABASE_PRINCIPAL_ID(N'hub_staff_demo') IS NULL CREATE USER hub_staff_demo WITHOUT LOGIN;
IF DATABASE_PRINCIPAL_ID(N'hub_user_1') IS NULL CREATE USER hub_user_1 WITHOUT LOGIN;
IF DATABASE_PRINCIPAL_ID(N'hub_user_2') IS NULL CREATE USER hub_user_2 WITHOUT LOGIN;
IF DATABASE_PRINCIPAL_ID(N'hub_guest_demo') IS NULL CREATE USER hub_guest_demo WITHOUT LOGIN;
GO
DECLARE @members TABLE(role_name SYSNAME,user_name SYSNAME);
INSERT @members VALUES
('hub_manager','hub_manager_demo'),('hub_staff','hub_staff_demo'),
('hub_customer','hub_user_1'),('hub_customer','hub_user_2'),('hub_guest','hub_guest_demo');
DECLARE @r SYSNAME,@u SYSNAME,@sql NVARCHAR(MAX);
DECLARE membership CURSOR LOCAL FAST_FORWARD FOR SELECT role_name,user_name FROM @members;
OPEN membership;
FETCH NEXT FROM membership INTO @r,@u;
WHILE @@FETCH_STATUS=0
BEGIN
    IF NOT EXISTS(SELECT 1 FROM sys.database_role_members
                  WHERE role_principal_id=DATABASE_PRINCIPAL_ID(@r)
                    AND member_principal_id=DATABASE_PRINCIPAL_ID(@u))
    BEGIN
        SET @sql=N'ALTER ROLE '+QUOTENAME(@r)+N' ADD MEMBER '+QUOTENAME(@u)+N';';
        EXEC sys.sp_executesql @sql;
    END;
    FETCH NEXT FROM membership INTO @r,@u;
END;
CLOSE membership;
DEALLOCATE membership;
GO
```

- [ ] 对照矩阵逐项授权。管理员的基表授权用固定表名清单，避免将未来增加的任意表自动纳入。

```sql
DECLARE @tables TABLE(name SYSNAME);
INSERT @tables VALUES ('Roles'),('Users'),('Products'),('UpstreamAccount'),
('Inventory'),('Employees'),('Orders'),('OrderDetails'),('InventoryLog'),
('TokenBalances'),('TokenUsageLogs'),('UsageSummary'),('RestockTask'),('ExceptionLog');
DECLARE @t SYSNAME,@grant NVARCHAR(MAX);
DECLARE grants CURSOR LOCAL FAST_FORWARD FOR SELECT name FROM @tables;
OPEN grants;
FETCH NEXT FROM grants INTO @t;
WHILE @@FETCH_STATUS=0
BEGIN
    SET @grant=N'GRANT SELECT,INSERT,UPDATE,DELETE ON OBJECT::dbo.'+
       QUOTENAME(@t)+N' TO hub_manager;';
    EXEC sys.sp_executesql @grant;
    FETCH NEXT FROM grants INTO @t;
END;
CLOSE grants;
DEALLOCATE grants;
GRANT SELECT ON dbo.v_ProductCatalog TO hub_manager,hub_staff,hub_customer,hub_guest;
GRANT SELECT ON dbo.v_OrderDetail TO hub_manager,hub_staff;
GRANT SELECT ON dbo.v_ProductSales TO hub_manager,hub_staff;
GRANT SELECT ON dbo.v_MemberSpending TO hub_manager,hub_staff;
GRANT SELECT ON dbo.v_InventoryStatus TO hub_manager,hub_staff;
GRANT SELECT ON dbo.v_StaffOrderQueue TO hub_manager,hub_staff;
GRANT UPDATE ON dbo.v_StaffOrderQueue(status) TO hub_staff;
GRANT SELECT ON dbo.v_MyOrders TO hub_customer;
GRANT SELECT ON dbo.v_MyBalances TO hub_customer;
GRANT SELECT ON dbo.v_MyUsage TO hub_customer;
GO
```

- [ ] 执行以下权限用例。每条执行前切换到表中的用户，事务结束和 REVERT 后检查原身份恢复。关键读取要使用带断言的 SELECT，禁止把返回空结果也当作正常查询通过。

| ID | 用户 | SQL | 预期 |
|---|---|---|---|
| R01 | hub_guest_demo | `IF (SELECT COUNT(*) FROM dbo.v_ProductCatalog)<>10 THROW 51201,N'Catalog count mismatch',1;` | 成功 |
| R02 | hub_guest_demo | `SELECT TOP(1) order_id FROM dbo.Orders;` | 229 |
| R03 | hub_staff_demo | `IF (SELECT COUNT(*) FROM dbo.v_OrderDetail)<>184 THROW 51203,N'Detail count mismatch',1;` | 成功 |
| R04 | hub_staff_demo | `UPDATE dbo.Products SET price=price+1 WHERE product_id=1;` | 229 |
| R05 | hub_staff_demo | `DECLARE @id INT=(SELECT MIN(order_id) FROM dbo.v_StaffOrderQueue WHERE status='pending'); IF @id IS NULL THROW 51205,N'Missing pending order',1; UPDATE dbo.v_StaffOrderQueue SET status='cancelled' WHERE order_id=@id; IF @@ROWCOUNT<>1 THROW 51206,N'Update count mismatch',1;` | 成功后回滚 |
| R06 | hub_user_1 | `IF (SELECT COUNT(*) FROM dbo.v_MyOrders)<>13 OR EXISTS(SELECT 1 FROM dbo.v_MyOrders WHERE user_id<>1) THROW 51207,N'User 1 isolation failed',1; SELECT * FROM dbo.v_MyOrders ORDER BY order_id;` | 成功，只含用户 1 |
| R07 | hub_user_2 | `IF (SELECT COUNT(*) FROM dbo.v_MyOrders)<>15 OR EXISTS(SELECT 1 FROM dbo.v_MyOrders WHERE user_id<>2) THROW 51208,N'User 2 isolation failed',1; SELECT * FROM dbo.v_MyOrders ORDER BY order_id;` | 成功，只含用户 2 |
| R08 | hub_user_1 | `SELECT TOP(1) order_id FROM dbo.Orders;` | 229 |
| R09 | hub_user_1 | `SELECT api_key FROM dbo.UpstreamAccount;` | 229 |
| R10 | hub_user_1 | `IF EXISTS(SELECT 1 FROM dbo.v_MyOrders WHERE user_id=2) THROW 51210,N'Other user visible',1; IF NOT EXISTS(SELECT 1 FROM dbo.v_MyBalances) OR EXISTS(SELECT 1 FROM dbo.v_MyBalances WHERE user_id<>1) THROW 51211,N'Balance isolation failed',1; IF NOT EXISTS(SELECT 1 FROM dbo.v_MyUsage) OR EXISTS(SELECT 1 FROM dbo.v_MyUsage WHERE user_id<>1) THROW 51212,N'Usage isolation failed',1;` | 成功，不能通过 WHERE 绕过过滤 |
| R11 | hub_manager_demo | `UPDATE dbo.Products SET price=price+1 WHERE product_id=1; IF @@ROWCOUNT<>1 THROW 51213,N'Manager update failed',1;` | 成功后回滚 |
| R12 | hub_manager_demo | `IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','CREATE TABLE'),0)<>0 OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','CONTROL'),0)<>0 THROW 51214,N'Manager overprivileged',1;` | 成功，证实无 DDL/CONTROL 权限 |
| R13 | hub_staff_demo | `UPDATE dbo.v_StaffOrderQueue SET user_id=user_id WHERE order_id=(SELECT MIN(order_id) FROM dbo.v_StaffOrderQueue);` | 230，user_id 列没有 UPDATE 权限 |

角色用例驱动器及完整测试数据如下：

```sql
SET XACT_ABORT ON;
CREATE TABLE #RoleCases(
  case_id VARCHAR(4) PRIMARY KEY,actor SYSNAME,
  statement_sql NVARCHAR(MAX),expected_error INT
);
INSERT #RoleCases VALUES
('R01','hub_guest_demo',N'IF (SELECT COUNT(*) FROM dbo.v_ProductCatalog)<>10 THROW 51201,N''Catalog count mismatch'',1;',0),
('R02','hub_guest_demo',N'SELECT TOP(1) order_id FROM dbo.Orders;',229),
('R03','hub_staff_demo',N'IF (SELECT COUNT(*) FROM dbo.v_OrderDetail)<>184 THROW 51203,N''Detail count mismatch'',1;',0),
('R04','hub_staff_demo',N'UPDATE dbo.Products SET price=price+1 WHERE product_id=1;',229),
('R05','hub_staff_demo',N'DECLARE @id INT=(SELECT MIN(order_id) FROM dbo.v_StaffOrderQueue WHERE status=''pending''); IF @id IS NULL THROW 51205,N''Missing pending order'',1; UPDATE dbo.v_StaffOrderQueue SET status=''cancelled'' WHERE order_id=@id; IF @@ROWCOUNT<>1 THROW 51206,N''Update count mismatch'',1;',0),
('R06','hub_user_1',N'IF (SELECT COUNT(*) FROM dbo.v_MyOrders)<>13 OR EXISTS(SELECT 1 FROM dbo.v_MyOrders WHERE user_id<>1) THROW 51207,N''User 1 isolation failed'',1; SELECT * FROM dbo.v_MyOrders ORDER BY order_id;',0),
('R07','hub_user_2',N'IF (SELECT COUNT(*) FROM dbo.v_MyOrders)<>15 OR EXISTS(SELECT 1 FROM dbo.v_MyOrders WHERE user_id<>2) THROW 51208,N''User 2 isolation failed'',1; SELECT * FROM dbo.v_MyOrders ORDER BY order_id;',0),
('R08','hub_user_1',N'SELECT TOP(1) order_id FROM dbo.Orders;',229),
('R09','hub_user_1',N'SELECT api_key FROM dbo.UpstreamAccount;',229),
('R10','hub_user_1',N'IF EXISTS(SELECT 1 FROM dbo.v_MyOrders WHERE user_id=2) THROW 51210,N''Other user visible'',1; IF NOT EXISTS(SELECT 1 FROM dbo.v_MyBalances) OR EXISTS(SELECT 1 FROM dbo.v_MyBalances WHERE user_id<>1) THROW 51211,N''Balance isolation failed'',1; IF NOT EXISTS(SELECT 1 FROM dbo.v_MyUsage) OR EXISTS(SELECT 1 FROM dbo.v_MyUsage WHERE user_id<>1) THROW 51212,N''Usage isolation failed'',1;',0),
('R11','hub_manager_demo',N'UPDATE dbo.Products SET price=price+1 WHERE product_id=1; IF @@ROWCOUNT<>1 THROW 51213,N''Manager update failed'',1;',0),
('R12','hub_manager_demo',N'IF COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),''DATABASE'',''CREATE TABLE''),0)<>0 OR COALESCE(HAS_PERMS_BY_NAME(DB_NAME(),''DATABASE'',''CONTROL''),0)<>0 THROW 51214,N''Manager overprivileged'',1;',0),
('R13','hub_staff_demo',N'UPDATE dbo.v_StaffOrderQueue SET user_id=user_id WHERE order_id=(SELECT MIN(order_id) FROM dbo.v_StaffOrderQueue);',230);
DECLARE @case VARCHAR(4),@actor SYSNAME,@stmt NVARCHAR(MAX),@want INT,
        @got INT,@msg NVARCHAR(4000),@switched BIT,
        @original SYSNAME=USER_NAME();
DECLARE role_cases CURSOR LOCAL FAST_FORWARD FOR
SELECT case_id,actor,statement_sql,expected_error FROM #RoleCases ORDER BY case_id;
OPEN role_cases;
FETCH NEXT FROM role_cases INTO @case,@actor,@stmt,@want;
WHILE @@FETCH_STATUS=0
BEGIN
    SELECT @got=0,@msg=N'',@switched=0;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXECUTE AS USER=@actor;
        SET @switched=1;
        EXEC sys.sp_executesql @stmt;
        REVERT;
        SET @switched=0;
        ROLLBACK TRANSACTION;
    END TRY
    BEGIN CATCH
        SELECT @got=ERROR_NUMBER(),@msg=ERROR_MESSAGE();
        IF @switched=1 REVERT;
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    END CATCH;
    IF USER_NAME()<>@original THROW 51298,N'Execution context not restored',1;
    IF @got<>@want
    BEGIN
        SET @msg=CONCAT(@case,N' failed; expected=',@want,N'; actual=',@got,N'; ',@msg);
        THROW 51299,@msg,1;
    END;
    SELECT @case AS case_id,@actor AS actor,N'PASS' AS result,
           @got AS actual_error,@msg AS actual_message;
    FETCH NEXT FROM role_cases INTO @case,@actor,@stmt,@want;
END;
CLOSE role_cases;
DEALLOCATE role_cases;
DROP TABLE #RoleCases;
```

- [ ] R13 若在实际实例返回不同的具体权限错误，先确认是权限原因，再记录实际错误号及调整理由，不能笼统吞掉任何异常。
- [ ] 将以下权限审计代码加入 role.sql 末尾；个人视图依靠同一 dbo 所有权链读取基表，不额外开放基表权限。

```sql
EXECUTE AS USER='hub_staff_demo';
SELECT * FROM sys.fn_my_permissions('dbo.v_StaffOrderQueue','OBJECT');
REVERT;
IF EXISTS(
    SELECT 1 FROM sys.database_role_members m
    JOIN sys.database_principals r ON r.principal_id=m.role_principal_id
    JOIN sys.database_principals u ON u.principal_id=m.member_principal_id
    WHERE r.is_fixed_role=1 AND u.name IN
      ('hub_manager','hub_staff','hub_customer','hub_guest','hub_manager_demo',
       'hub_staff_demo','hub_user_1','hub_user_2','hub_guest_demo')
) THROW 51290,N'Unexpected fixed-role membership',1;
IF EXISTS(
    SELECT 1 FROM sys.database_permissions p
    JOIN sys.objects o ON o.object_id=p.major_id
    WHERE p.class=1 AND p.grantee_principal_id=DATABASE_PRINCIPAL_ID('public')
      AND o.schema_id=SCHEMA_ID('dbo') AND o.type IN ('U','V')
      AND p.state IN ('G','W')
) THROW 51291,N'Public has business-object access',1;
EXECUTE AS USER='hub_user_1';
DECLARE @can_impersonate INT=HAS_PERMS_BY_NAME('hub_user_2','USER','IMPERSONATE');
REVERT;
IF COALESCE(@can_impersonate,0)<>0 THROW 51292,N'Customer can impersonate another user',1;
```

**完成标准：** 权限正反例、列级更新限制、两名会员行隔离全部通过；脚本结束 `USER_NAME()` 恢复原身份且 `@@TRANCOUNT=0`。

```powershell
sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -f 65001 -u `
  -v 'DatabaseName=TokenHubDB_v01_Dev' -i .\sql\role.sql -o .\result\dev\role.sql.log
if ($LASTEXITCODE -ne 0) { throw 'Role verification failed' }
```

## T7 综合断言、边界数据与双空库复现

**文件：** 完成 `sql/verify.sql`；创建 `sql/signature.sql`、`tools/run_v01.ps1`。

### 综合断言

- [ ] 在 verify.sql 建立行数清单并逐表断言；同时用于签名脚本的表名和主键映射，避免靠 sys.tables 的返回顺序。

```sql
DECLARE @expected TABLE(table_name SYSNAME,pk_name SYSNAME,row_count INT);
INSERT @expected VALUES
('Roles','role_id',3),('Users','user_id',40),('Products','product_id',10),
('UpstreamAccount','account_id',8),('Inventory','inventory_id',8),
('Employees','employee_id',6),('Orders','order_id',100),
('OrderDetails','detail_id',184),('InventoryLog','log_id',3012),
('TokenBalances','balance_id',61),('TokenUsageLogs','log_id',3000),
('UsageSummary','summary_id',3394),('RestockTask','task_id',8),
('ExceptionLog','exception_id',15);
DECLARE @table SYSNAME,@expected_count INT,@actual BIGINT,@sql NVARCHAR(MAX);
DECLARE row_counts CURSOR LOCAL FAST_FORWARD FOR SELECT table_name,row_count FROM @expected;
OPEN row_counts;
FETCH NEXT FROM row_counts INTO @table,@expected_count;
WHILE @@FETCH_STATUS=0
BEGIN
    SET @sql=N'SELECT @n=COUNT_BIG(*) FROM dbo.'+QUOTENAME(@table)+N';';
    EXEC sys.sp_executesql @sql,N'@n BIGINT OUTPUT',@n=@actual OUTPUT;
    IF @actual<>@expected_count THROW 51301,N'Baseline row count mismatch',1;
    FETCH NEXT FROM row_counts INTO @table,@expected_count;
END;
CLOSE row_counts;
DEALLOCATE row_counts;
```

- [ ] 加入以下业务断言，覆盖第 4 节全部核心指标。

```sql
IF (SELECT SUM(total_amount) FROM dbo.Orders)<>4931.00
 OR (SELECT SUM(total_tokens) FROM dbo.Orders)<>108950000
 OR (SELECT SUM(total_tokens) FROM dbo.Orders WHERE status='paid')<>92950000
    THROW 51320,N'Order totals mismatch',1;
IF (SELECT COUNT(*) FROM dbo.OrderDetails d JOIN dbo.Orders o ON o.order_id=d.order_id
     WHERE o.status='paid')<>158
    THROW 51321,N'Paid detail count mismatch',1;
IF (SELECT SUM(CAST(tokens_used AS BIGINT)) FROM dbo.TokenUsageLogs)<>6040100
 OR (SELECT SUM(CAST(upstream_tokens_consumed AS BIGINT)) FROM dbo.TokenUsageLogs)<>7248120
    THROW 51322,N'Raw usage totals mismatch',1;
IF (SELECT SUM(current_quota) FROM dbo.Inventory)<>6350000
 OR (SELECT SUM(change_amount) FROM dbo.InventoryLog)<>6350000
    THROW 51323,N'Inventory totals mismatch',1;
IF (SELECT COUNT(*) FROM dbo.v_OrderDetail)<>184
 OR (SELECT COUNT(*) FROM dbo.v_MemberSpending)<>40
 OR (SELECT COUNT(*) FROM dbo.v_InventoryStatus)<>8
 OR (SELECT COUNT(*) FROM dbo.v_InventoryStatus WHERE stock_state='low')<>0
    THROW 51324,N'Core view row counts mismatch',1;
IF (SELECT SUM(revenue) FROM dbo.v_ProductSales)<>4228.90
 OR (SELECT SUM(units_sold) FROM dbo.v_ProductSales)<>191
 OR (SELECT SUM(tokens_sold) FROM dbo.v_ProductSales)<>92950000
    THROW 51302,N'Product sales mismatch',1;
IF (SELECT COUNT(*) FROM dbo.v_MemberSpending WHERE paid_orders=0)<>14
 OR (SELECT COUNT(*) FROM dbo.v_MemberSpending WHERE paid_amount>=100)<>13
    THROW 51303,N'Member spending mismatch',1;
IF EXISTS (
    SELECT period_type FROM dbo.UsageSummary GROUP BY period_type
    HAVING SUM(total_tokens_used)<>6040100
       OR SUM(total_upstream_consumed)<>7248120 OR SUM(request_count)<>3000
) OR (SELECT COUNT(DISTINCT period_type) FROM dbo.UsageSummary)<>3
    THROW 51304,N'Usage summary grain mismatch',1;
IF EXISTS (
    SELECT 1 FROM dbo.Orders o LEFT JOIN (
        SELECT order_id,SUM(subtotal) amount,SUM(total_tokens) tokens
        FROM dbo.OrderDetails GROUP BY order_id
    ) d ON d.order_id=o.order_id
    WHERE d.order_id IS NULL OR o.total_amount<>d.amount OR o.total_tokens<>d.tokens
) THROW 51305,N'Order header/detail mismatch',1;
IF EXISTS (
    SELECT 1 FROM dbo.UpstreamAccount a
    LEFT JOIN dbo.Inventory i ON i.account_id=a.account_id
    LEFT JOIN (SELECT account_id,SUM(change_amount) balance FROM dbo.InventoryLog
               GROUP BY account_id) l ON l.account_id=a.account_id
    WHERE i.account_id IS NULL OR l.account_id IS NULL
       OR i.current_quota<>a.total_quota-a.used_quota OR i.current_quota<>l.balance
) THROW 51306,N'Account/inventory/log mismatch',1;
IF EXISTS(SELECT 1 FROM sys.foreign_keys WHERE is_disabled=1 OR is_not_trusted=1)
 OR EXISTS(SELECT 1 FROM sys.check_constraints WHERE is_disabled=1 OR is_not_trusted=1)
    THROW 51307,N'Disabled or untrusted constraint',1;
IF (SELECT COUNT(*) FROM sys.views WHERE is_ms_shipped=0)<>9
    THROW 51308,N'View count mismatch',1;
IF @@TRANCOUNT<>0 THROW 51309,N'Open transaction remains',1;
IF (SELECT COUNT(*) FROM sys.database_principals
    WHERE type='R' AND name IN ('hub_manager','hub_staff','hub_customer','hub_guest'))<>4
 OR (SELECT COUNT(*) FROM sys.database_principals
     WHERE type='S' AND name IN ('hub_manager_demo','hub_staff_demo',
                                'hub_user_1','hub_user_2','hub_guest_demo'))<>5
    THROW 51325,N'Role or demonstration user missing',1;
IF (SELECT COUNT(*) FROM sys.check_constraints WHERE name IN
    ('CK_OrderDetails_subtotal_formula','CK_OrderDetails_tokens_formula',
     'CK_Orders_payment_time'))<>3
    THROW 51326,N'New cross-column constraints missing',1;
IF EXISTS(
    SELECT user_id FROM dbo.v_MemberSpending WHERE paid_orders=0
    EXCEPT SELECT id FROM (VALUES(9),(16),(19),(22),(23),(25),(28),
                                (29),(31),(36),(37),(38),(39),(40)) e(id)
) OR EXISTS(
    SELECT user_id FROM dbo.v_MemberSpending WHERE paid_amount>=100
    EXCEPT SELECT id FROM (VALUES(1),(2),(3),(5),(8),(11),(12),(15),
                                (17),(18),(24),(33),(35)) e(id)
) THROW 51327,N'Member identity set mismatch',1;
```

- [ ] 对商品销售和会员消费做逐行核对；独立参考查询按商品/用户逐个聚合，双向 EXCEPT 检查错行、漏行、多行。

```sql
SELECT p.product_id,p.name,p.model_provider,
       COALESCE(x.units_sold,0) AS units_sold,
       COALESCE(x.revenue,0) AS revenue,COALESCE(x.tokens_sold,0) AS tokens_sold
INTO #ProductReference
FROM dbo.Products p OUTER APPLY(
    SELECT SUM(CAST(d.quantity AS BIGINT)) AS units_sold,
           SUM(d.subtotal) AS revenue,SUM(d.total_tokens) AS tokens_sold
    FROM dbo.OrderDetails d
    WHERE d.product_id=p.product_id AND EXISTS(
        SELECT 1 FROM dbo.Orders o WHERE o.order_id=d.order_id AND o.status='paid'
    )
) x;
IF EXISTS(SELECT * FROM #ProductReference EXCEPT SELECT * FROM dbo.v_ProductSales)
 OR EXISTS(SELECT * FROM dbo.v_ProductSales EXCEPT SELECT * FROM #ProductReference)
    THROW 51330,N'Product view row differences',1;
DROP TABLE #ProductReference;
SELECT u.user_id,u.username,x.paid_orders,
       COALESCE(x.paid_amount,0) AS paid_amount,COALESCE(x.paid_tokens,0) AS paid_tokens
INTO #MemberReference
FROM dbo.Users u OUTER APPLY(
    SELECT COUNT(*) AS paid_orders,SUM(o.total_amount) AS paid_amount,
           SUM(o.total_tokens) AS paid_tokens
    FROM dbo.Orders o WHERE o.user_id=u.user_id AND o.status='paid'
) x;
IF EXISTS(SELECT * FROM #MemberReference EXCEPT SELECT * FROM dbo.v_MemberSpending)
 OR EXISTS(SELECT * FROM dbo.v_MemberSpending EXCEPT SELECT * FROM #MemberReference)
    THROW 51331,N'Member view row differences',1;
DROP TABLE #MemberReference;
```

- [ ] 对余额做逐用户、逐 provider 对账，保留任意一侧缺失的键。

```sql
WITH credits AS(
    SELECT o.user_id,p.model_provider,SUM(d.total_tokens) AS purchased
    FROM dbo.Orders o JOIN dbo.OrderDetails d ON d.order_id=o.order_id
    JOIN dbo.Products p ON p.product_id=d.product_id
    WHERE o.status='paid' GROUP BY o.user_id,p.model_provider
), used AS(
    SELECT l.user_id,p.model_provider,SUM(CAST(l.tokens_used AS BIGINT)) AS consumed
    FROM dbo.TokenUsageLogs l JOIN dbo.Products p ON p.product_id=l.product_id
    GROUP BY l.user_id,p.model_provider
)
SELECT COALESCE(c.user_id,u.user_id) AS user_id,
       COALESCE(c.model_provider,u.model_provider) AS model_provider,
       COALESCE(c.purchased,0)-COALESCE(u.consumed,0) AS remaining_tokens
INTO #BalanceReference
FROM credits c FULL JOIN used u
 ON u.user_id=c.user_id AND u.model_provider=c.model_provider;
IF EXISTS(SELECT * FROM #BalanceReference
          EXCEPT SELECT user_id,model_provider,remaining_tokens FROM dbo.TokenBalances)
 OR EXISTS(SELECT user_id,model_provider,remaining_tokens FROM dbo.TokenBalances
           EXCEPT SELECT * FROM #BalanceReference)
    THROW 51332,N'Balance per-user/provider mismatch',1;
DROP TABLE #BalanceReference;
```

- [ ] 对三个 UsageSummary 粒度逐用户、商品及周期与原始日志独立聚合比对；周一为周起点，固定日期算法，不依赖 DATEFIRST。

```sql
WITH dated AS(
    SELECT l.*,CONVERT(DATE,l.used_at) AS used_date,
      DATEADD(DAY,-(DATEDIFF(DAY,CONVERT(DATE,'19000101'),CONVERT(DATE,l.used_at))%7),
              CONVERT(DATE,l.used_at)) AS week_start
    FROM dbo.TokenUsageLogs l
)
SELECT d.user_id,d.product_id,p.period_type,p.period_start,p.period_end,
       SUM(CAST(d.tokens_used AS BIGINT)) AS total_tokens_used,
       SUM(CAST(d.upstream_tokens_consumed AS BIGINT)) AS total_upstream_consumed,
       COUNT(*) AS request_count
INTO #SummaryReference
FROM dated d CROSS APPLY(VALUES
    ('daily',d.used_date,d.used_date),
    ('weekly',d.week_start,DATEADD(DAY,6,d.week_start)),
    ('monthly',DATEFROMPARTS(YEAR(d.used_date),MONTH(d.used_date),1),EOMONTH(d.used_date))
) p(period_type,period_start,period_end)
GROUP BY d.user_id,d.product_id,p.period_type,p.period_start,p.period_end;
IF EXISTS(
    SELECT * FROM #SummaryReference EXCEPT
    SELECT user_id,product_id,period_type,period_start,period_end,
           total_tokens_used,total_upstream_consumed,request_count FROM dbo.UsageSummary
) OR EXISTS(
    SELECT user_id,product_id,period_type,period_start,period_end,
           total_tokens_used,total_upstream_consumed,request_count FROM dbo.UsageSummary
    EXCEPT SELECT * FROM #SummaryReference
) THROW 51333,N'Usage summary per-key mismatch',1;
DROP TABLE #SummaryReference;
```

### 无销售与低库存边界正例

- [ ] 在 verify.sql 中加入以下完整事务。该测试证明零销量商品不会被连接过滤掉，也证明低库存视图确实能返回正例。

```sql
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;
    INSERT dbo.Products(name,price,model_provider,token_amount,required_upstream_tokens)
    VALUES(N'W4零销量边界',1,'Other',910001,910001);
    DECLARE @p INT=SCOPE_IDENTITY();
    IF NOT EXISTS(SELECT 1 FROM dbo.v_ProductSales WHERE product_id=@p
                  AND units_sold=0 AND revenue=0 AND tokens_sold=0)
        THROW 51310,N'Zero-sales product missing',1;
    INSERT dbo.UpstreamAccount(provider,account_name,api_key,total_quota,
      used_quota,safety_threshold,status,expires_at)
    VALUES('Other',N'W4低库存边界',N'DEMO_NOT_A_REAL_API_KEY_W4',1000,900,200,
      'active','2027-12-31');
    DECLARE @a INT=SCOPE_IDENTITY();
    INSERT dbo.Inventory(account_id,current_quota) VALUES(@a,100);
    INSERT dbo.InventoryLog(account_id,change_type,change_amount,reason)
    VALUES(@a,'purchase',1000,N'W4边界期初'),(@a,'consumption',-900,N'W4边界消耗');
    IF NOT EXISTS(SELECT 1 FROM dbo.v_InventoryStatus WHERE account_id=@a AND stock_state='low')
        THROW 51311,N'Low quota account missing',1;
    ROLLBACK TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
PRINT N'PASS v0.1 verification';
```

### 数据签名

- [ ] 创建 signature.sql，不包含 USE 或数据库名称，执行时通过 sqlcmd 的 `-d` 选择库。完整内容如下；按主键排序、JSON 包含 NULL、对完整表内容求 SHA256。

```sql
SET NOCOUNT ON;
DECLARE @expected TABLE(table_name SYSNAME,pk_name SYSNAME);
INSERT @expected VALUES
('Roles','role_id'),('Users','user_id'),('Products','product_id'),
('UpstreamAccount','account_id'),('Inventory','inventory_id'),
('Employees','employee_id'),('Orders','order_id'),('OrderDetails','detail_id'),
('InventoryLog','log_id'),('TokenBalances','balance_id'),('TokenUsageLogs','log_id'),
('UsageSummary','summary_id'),('RestockTask','task_id'),('ExceptionLog','exception_id');
DECLARE @t SYSNAME,@pk SYSNAME,@stmt NVARCHAR(MAX);
CREATE TABLE #Signatures(table_name SYSNAME,rows_count BIGINT,sha256 VARCHAR(64));
DECLARE signatures CURSOR LOCAL FAST_FORWARD FOR
SELECT table_name,pk_name FROM @expected ORDER BY table_name;
OPEN signatures;
FETCH NEXT FROM signatures INTO @t,@pk;
WHILE @@FETCH_STATUS=0
BEGIN
    SET @stmt=N'DECLARE @j NVARCHAR(MAX); SELECT @j=(SELECT * FROM dbo.'+
      QUOTENAME(@t)+N' ORDER BY '+QUOTENAME(@pk)+
      N' FOR JSON PATH,INCLUDE_NULL_VALUES); INSERT #Signatures
      SELECT @name,COUNT_BIG(*),CONVERT(VARCHAR(64),HASHBYTES(''SHA2_256'',@j),2)
      FROM dbo.'+QUOTENAME(@t)+N';';
    EXEC sys.sp_executesql @stmt,N'@name SYSNAME',@name=@t;
    FETCH NEXT FROM signatures INTO @t,@pk;
END;
CLOSE signatures;
DEALLOCATE signatures;
SELECT CONCAT(table_name,'|',rows_count,'|',sha256)
FROM #Signatures ORDER BY table_name;
DROP TABLE #Signatures;
```

### 一键复现入口

- [ ] 创建 `tools/run_v01.ps1`，使用以下实现。输入数据库名限定为本项目实验库格式；现有库由 00 脚本拒绝覆盖；脚本始终使用 Windows 身份验证，不硬编码密码。

```powershell
param(
    [string]$Server = 'localhost\SQLEXPRESS',
    [ValidatePattern('^TokenHubDB_v01(?:_[A-Za-z0-9]+)?$')]
    [string]$DatabaseName = 'TokenHubDB_v01_A',
    [ValidatePattern('^[A-Za-z0-9_]+$')]
    [string]$RunLabel = 'run_A'
)
$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $repoRoot "result/$RunLabel"
if (Test-Path -LiteralPath $outDir) {
    throw "Result directory already exists; choose a new RunLabel: $RunLabel"
}
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$files = @('00_create_database.sql','01_create_tables.sql','02_insert_data.sql',
           '03_crud_demo.sql','query.sql','view.sql','constraint.sql','role.sql','verify.sql')
foreach ($name in $files) {
    $inputFile = Join-Path $repoRoot "sql/$name"
    if (-not (Test-Path -LiteralPath $inputFile)) { throw "Missing script: $inputFile" }
}
if (-not (Test-Path -LiteralPath (Join-Path $repoRoot 'sql/signature.sql'))) {
    throw 'Missing script: sql/signature.sql'
}
Start-Transcript -Path (Join-Path $outDir 'console.log') | Out-Null
try {
    foreach ($name in $files) {
        $inputFile = Join-Path $repoRoot "sql/$name"
        $logFile = Join-Path $outDir "$name.log"
        & sqlcmd -S $Server -d master -E -C -b -r 1 -f 65001 -u `
          -v "DatabaseName=$DatabaseName" -i $inputFile -o $logFile
        if ($LASTEXITCODE -ne 0) { throw "FAILED $name; see $logFile and console.log" }
        Write-Output "PASS $name"
    }
    $signature = Join-Path $outDir 'signature.txt'
    & sqlcmd -S $Server -d $DatabaseName -E -C -b -f 65001 -u -h -1 -W `
      -i (Join-Path $repoRoot 'sql/signature.sql') -o $signature
    if ($LASTEXITCODE -ne 0) { throw 'FAILED signature.sql' }
    Write-Output "PASS v0.1 $DatabaseName"
}
finally {
    Stop-Transcript | Out-Null
}
```

日志由 `-u` 输出为 Unicode；负例脚本同时输出 actual_error 和 actual_message；`console.log` 捕获控制台错误。实际 SQL 文件清单不包括 signature.sql，因此流程打印 9 个脚本 PASS，另生成签名文件。

- [ ] 在首次完整执行前核对所有 SQLCMD 变量与文件路径，并确认目标库名未被使用。
- [ ] 第一次从空库运行，预期 9 个脚本逐个 PASS，最后输出 `PASS v0.1 TokenHubDB_v01_A`。

```powershell
powershell -NoProfile -File .\tools\run_v01.ps1 -DatabaseName TokenHubDB_v01_A -RunLabel run_A
```

- [ ] 第二次使用另一空库运行并比较签名，预期比较无输出，退出时没有异常。

```powershell
powershell -NoProfile -File .\tools\run_v01.ps1 -DatabaseName TokenHubDB_v01_B -RunLabel run_B
$diff = Compare-Object (Get-Content .\result\run_A\signature.txt) (Get-Content .\result\run_B\signature.txt)
if ($diff) { $diff | Format-Table; throw 'Reproduction signatures differ' }
Write-Output 'PASS two fresh databases have identical business data'
```

- [ ] 在 A 库单独重新执行第四周脚本；再次输出 signature，必须与 run_A 首次签名一致。以下重复验证日志保存至独立目录。

```powershell
New-Item -ItemType Directory -Path .\result\repeat_A -ErrorAction Stop | Out-Null
foreach ($name in @('view.sql','constraint.sql','role.sql','verify.sql')) {
    sqlcmd -S 'localhost\SQLEXPRESS' -E -C -b -f 65001 -u `
      -v 'DatabaseName=TokenHubDB_v01_A' -i ".\sql\$name" -o ".\result\repeat_A\$name.log"
    if ($LASTEXITCODE -ne 0) { throw "Repeat failed: $name" }
}
sqlcmd -S 'localhost\SQLEXPRESS' -d TokenHubDB_v01_A -E -C -b -f 65001 -u -h -1 -W `
  -i .\sql\signature.sql -o .\result\repeat_A\signature.txt
if ($LASTEXITCODE -ne 0) { throw 'Repeat signature failed' }
$repeatDiff = Compare-Object (Get-Content .\result\run_A\signature.txt) (Get-Content .\result\repeat_A\signature.txt)
if ($repeatDiff) { throw 'Repeated scripts changed baseline data' }
Write-Output 'PASS repeat execution preserves baseline data'
```
- [ ] 若某次执行失败，先保存失败日志，修复后使用新的实验库后缀及结果目录重试。删除旧库作为单独的清理动作处理，不放进一键脚本。

**完成标准：** 两次完整空库复现通过；关键数字、逐行对账、权限及负例均有断言；14 张表逐表内容签名一致；无测试行遗留。

## T8 文档、截图与真实验证记录

**文件：** 更新 README、DEMO_GUIDE；创建 week4 下四份文档以及 result/README.md。

- [ ] 更新 README 的项目范围、四种业务角色、用户购买与使用流程、数据库表分组、环境要求、实际目录结构和执行顺序。把所有第一、二周文档链接修正到 `week1%20%26%202/` 下，第三周计划指向 `week3/week3_plan.md`。
- [ ] README 说明 root/sql 四个基础脚本来自第三周，经 prepare_v01 转换；正常复现直接使用已提交的 root/sql，不需要每次重新生成；更新基线时才重新运行 prepare_v01。
- [ ] 在 DEMO_GUIDE 写出约 10 分钟的演示顺序：建库与行数 → CRUD → Q01/Q02/Q05 → 四个核心视图 → C06/C08 → R04/R06/R07 → 双空库签名。
- [ ] SSMS 连接 A 库，按以下清单保存实际截图；截图包含数据库名、执行 SQL 或用例 ID、结果/错误号。截图不能用模拟表格代替。

| 文件名（置于 result/screenshots/） | 内容与证据 |
|---|---|
| `01_database_tables.png` | 成功建库与 14 表列表/行数 |
| `02_crud_products.png` | 商品新增、修改、删除的前后结果 |
| `03_crud_inventory.png` | 上游账号与库存 CRUD 的前后结果 |
| `04_crud_orders.png` | 订单及明细 CRUD 的前后结果 |
| `05_join_query.png` | Q01 多表查询、关键字段对应 |
| `06_sales_and_members.png` | Q02 销售额及 Q05 无消费用户 |
| `07_statistical_views.png` | 四个核心视图的结果，可拆成多个连续文件 |
| `08_constraint_legal.png` | C01/C02 合法值成功，含默认值断言 |
| `09_constraint_illegal.png` | C05/C06/C08 非法值被拒，实际错误号及约束名 |
| `10_role_allowed_denied.png` | R03/R04/R05 正常读取、禁止改价、允许处理订单 |
| `11_customer_isolation.png` | R06/R07 不同会员仅看到本人订单 |
| `12_reproduction.png` | A/B 库签名比较 PASS 与两次执行入口 |

截图可按内容拆页，编号保持可追溯。读取实际截图工具时再使用相应技能；此计划不预设截图已经取得。

- [ ] 编写 `week4/stage_report.md`，结构固定为：
  1. 项目场景、经营角色与数据边界；
  2. 业务流程与 14 表的作用；
  3. 主键、候选键、外键及设计理由；
  4. 第三周到第四周的实施过程、实际执行环境；
  5. 查询口径、INNER/LEFT JOIN 区别、聚合及子查询结果；
  6. 视图设计与逐行验证；
  7. 现有与新增约束、合法/非法正反例；
  8. 数据库权限矩阵、正常/越权例、会员隔离；
  9. 空库复现和数据签名；
  10. 实验总结、局限及后续阶段衔接。
- [ ] 在局限中如实写明：数据为合成数据；用户注册时间与订单时间、上游账号历史状态不应被当作真实生产时序；本周保证声明的静态关系与权限，不把当前样例宣称为完整可上线交易系统。库存视图采用固定快照时间；业务角色和应用身份映射仍为教学演示。
- [ ] 编写 `week4/week4_deliverables.md`：逐项对应第 2 节，列出文件、运行日期、结果、截图和日志路径；任何未实际完成项保持未勾选。
- [ ] 编写 `week4/ai_usage_log.md`：记录本次需求原文、AI 建议（销售口径、视图过滤、错误捕获、双空库复现）、实际人工修改、复核人员、执行命令、验证结论与证据位置。不要用本计划代替实际使用记录，也不要虚构成员已测试。
- [ ] 编写 `week4/team_division.md`，沿用第三周实际分工：陈诗翰负责 SQL 与脚本；肖懿负责业务口径、模式/权限设计复核；阮依成负责测试、截图、报告与交付整合。三人共同检查能否解释所提交 SQL。
- [ ] `result/README.md` 按用例 ID 建立“脚本 → 原始日志 → 截图 → 结论”索引，记录日志编码。

**完成标准：** README 单独可用；第一至四周材料有完整入口；报告结论能指向实际日志；所有要求的截图可打开且内容清楚。

## T9 最终核对与交付

- [ ] 使用任务书逐行回查第 2 节映射，确认 query/view/constraint/role 四个指定文件齐全。
- [ ] 核对 README 中所有本地链接存在，命令的当前目录与相对路径一致；同学在新克隆目录按 README 再现时不得依赖作者机器的绝对路径。
- [ ] 检查正式 SQL 不残留 `TokenHubDB_Week3`、不包含真实密钥、不授权固定高权限角色、不忽略未预期 SQL 错误。

```powershell
rg -n 'TokenHubDB_Week3|db_owner|sysadmin|WITH NOCHECK|CONTINUE_AFTER_ERROR' .\sql .\tools
git diff --stat
git -c core.quotepath=false status --short
```

预期：禁止模式在正式 SQL 与执行脚本中无命中；若工具脚本含源数据库名替换字符串，只能出现在 prepare_v01 的源文件转换逻辑中，人工核对这类预期命中。

- [ ] 核对所有新增文本为 UTF-8，SQL 中中文常量使用 N 前缀；英文枚举与真实 DDL 一致。
- [ ] 核对结果目录包含成功日志与全部截图；若课程平台另要求 PDF/DOCX，按教师实际提交格式从最终报告导出并检查版式，再提交。任务书未指定报告扩展名，本计划默认 Markdown 源报告。
- [ ] 由另一名成员按 README 完成空库复现，登记实际人员、日期和库名；未做到前不得写“全组已复现”。
- [ ] 按功能形成可审阅提交；只添加本次文件，保留原有未跟踪目录。建议提交分组：基础脚本与查询视图、约束与权限、验收与复现、文档与证据。先检查 `git diff --cached`，再提交；推送按小组既有协作方式进行。

## 6. 工期与里程碑

以下为小组工作量估算，实际以每项验收结果为准。

| 里程碑 | 工作 | 建议负责 | 估算 |
|---|---|---|---|
| M1 | T1～T2，确认基线、文件和验收契约 | 陈诗翰，肖懿复核 | 30～45 分钟 |
| M2 | T3～T4，查询和视图 | 陈诗翰，肖懿复核口径 | 60～90 分钟 |
| M3 | T5～T6，约束和权限 | 陈诗翰，阮依成验证 | 90～150 分钟 |
| M4 | T7，逐行对账和两次空库复现 | 阮依成，陈诗翰修复反馈 | 60～90 分钟 |
| M5 | T8～T9，截图、阶段报告和交付 | 阮依成，三人交叉复核 | 90～150 分钟 |

每个里程碑结束保存代码与日志；后续任务以先前验收通过为前提。发生口径变化时先更新第 3、4 节，再同步查询、视图、断言和报告，避免文档与 SQL 各自采用不同定义。

## 7. 完成定义

> 本节已按 2026-10-01 修订后的实际规模更新（视图 10 个、查询 12 个、约束用例 14 个、权限用例 17 个、三个空库）。

- [x] 课程第四周四类 SQL 均可直接运行且有明确业务解释。
- [x] 14 张表、10 个视图、4 种数据库角色、5 个演示用户正确存在。
- [x] 12 个业务查询、14 个约束用例、17 个权限用例及边界测试通过。
- [x] 表行数、金额、Token、库存、汇总粒度与本计划基准一致，逐行对账无差异。
- [x] 三个空库复现的 14 张表内容签名完全一致；重复运行第四周脚本不改变基础数据。
- [x] README、SQL、结果证据、阶段报告、AI 记录与组内分工齐全。
- [ ] 另一名成员能够按 README 复现并解释查询口径、约束正反例及权限差异。

达到全部条件后，将 `week4/week4_deliverables.md` 的阶段结论标记为“v0.1 验收通过”，并在 README 更新第四周完成状态。

---

## 8. 2026-09-30 实际执行状态

以下状态来自 sh 机器真实执行结果；原计划中的逐步复选框保留作为实施说明，本节作为唯一最终执行记录。

- [x] T1：环境、SQLCMD 变量化基础脚本与 Dev 基线验证完成。
- [x] T2：最终验收契约已落实到 `sql/verify.sql`。
- [x] T3：Q01～Q08 已在 SQL Server 实际执行成功。
- [x] T4：9 个视图创建并验证，重复执行成功。
- [x] T5：3 个新增 CHECK、C01～C11 全部 PASS。
- [x] T6：4 个数据库角色、5 个演示用户、R01～R13 与权限审计全部 PASS。
- [x] T7：A/B 两个空库完整复现成功，14 表 SHA-256 内容签名一致；A 库重复执行第四周脚本签名不变。
- [x] T8：README、DEMO_GUIDE、阶段报告、交付清单、AI 使用记录、分工和结果索引完成。
- [x] T8 截图：`result/screenshots/` 已生成 22 张真实 SQL Server 执行截图（01～12 为基线版本，13～22 为 2026-10-01 修订版本）；对应 SQL/日志位于 `result/evidence_sql/`、`result/evidence_logs/`。
- [x] T9 自动核对：README/文档本地链接、UTF-8、中文 SQL N 前缀、文件清单、Git whitespace、截图数量和签名一致性均通过。
- [x] 结果清理：开发阶段重复日志、IDE/Python 缓存和临时文件已清理；AI 日志统一为 `week4/ai_usage_log.md`。
- [ ] T9 同伴复现：尚未由第二名成员在独立环境执行，不能标记完成。
- [ ] T9 提交/推送：尚未执行，等待最终人工复核后处理。

当前结论：**v0.1 技术交付物、自动验收与结果截图已完成；仅团队独立复现登记和 Git 提交/推送待后续动作。**

---

## 9. 2026-10-01 v0.1 修订记录

本节记录第四周评审后的修订，以及修订后在本机的重新验收。第 1～7 节的计划数字（9 视图、Q01～Q08、C01～C11、R01～R13、A/B 两库）保留为实施原文，实际口径以本节为准。

### 9.1 修订动因

| # | 评审问题 | 处理结论 |
|---|---|---|
| 1 | 店员要联系客户，但直接读 `dbo.Users` 会暴露 `password_hash` | 新增客服视图 `v_CustomerService`，只暴露联系方式与订单/余额聚合 |
| 2 | 第一周允许会员下单、支付、改资料，v0.1 却无会员写权限 | 确认为已知差异，写入阶段报告并说明改由第三阶段存储过程实现 |
| 3 | Q06 低库存查询结果恒为空，演示无输出 | 新增 Q09：事务内造阈值边界账号、查询后回滚 |
| 4 | 查询缺少连接方式对照、汇总趋势与消耗分析 | 新增 Q10（INNER/LEFT 对照）、Q11（UsageSummary 趋势）、Q12（InventoryLog 消耗排名） |
| 5 | 完整性反例只覆盖 CHECK 与外键 | 新增 C12、C13（复合候选码）、C14（JSON 域） |
| 6 | `v_InventoryStatus` 把账号状态写进 `stock_state`，低库存显示成“过期” | 拆为 `account_state` 与 `stock_state`，新增 `quota_headroom` |
| 7 | `signature.sql` 独立执行时不知道目标库 | 补 `USE [$(DatabaseName)]`，并让输出只含签名行以便跨库比较 |
| 8 | 重复演示时空库已存在导致 THROW 50001 中断 | `run_v01.ps1` 增加可选 `-DropExisting`，默认仍不自动删库 |
| 9 | 本机执行策略限制导致脚本无法运行 | README 与 DEMO_GUIDE 补充 `-ExecutionPolicy Bypass` 调用方式 |
| 10 | 文档对象数量与实际不一致 | 视图 9→10、Q→Q12、C→C14、R→R17 逐份同步 |

### 9.2 实际改动文件

| 文件 | 改动 |
|---|---|
| `sql/view.sql` | 新增 `v_CustomerService`（V05）；`v_InventoryStatus` 拆分 `account_state`/`stock_state` 并新增 `quota_headroom`；顶部注释标注快照时点与 `query.sql` 共用 |
| `sql/query.sql` | Q06 增加低库存计数结果集；新增 Q09～Q12 |
| `sql/constraint.sql` | 新增 C12～C14，PASS 断言由 11 例改为 14 例 |
| `sql/role.sql` | 授予 `v_CustomerService` 给 `hub_manager`/`hub_staff`；新增 R14～R17；补充会员写权限延后的原因注释；PASS 断言由 13 例改为 17 例；权限审计增加客服视图与 `dbo.Users` |
| `sql/verify.sql` | 视图数 9→10；新增低库存分类一致性、命中行数、`quota_headroom`、会员/游客无写权限、会员/店员无基表权限、店长 14 表 CRUD 齐全等断言 |
| `sql/signature.sql` | 增加 `USE [$(DatabaseName)]` |
| `tools/run_v01.ps1` | 视图提前到查询之前；`-DropExisting` 开关；签名调用传 `-v`；签名输出过滤为 14 行签名行 |
| `report/` | 新增 `stage_report.md`、`role_workflow.md`（ER 图与项目知识导图已并入 `stage_report.md`） |
| 根目录 | 新增 `ai_usage_log.md`、`team_division.md`；`README.md` 更新目录结构、执行顺序、复现命令与实测结论 |
| `DEMO_GUIDE.md`、`sql/README.md`、`result/README.md`、`result/screenshots/README.md`、`week4/week4_deliverables.md` | 同步查询/视图/约束/权限数量、证据目录与演示步骤 |

`sql/01_create_tables.sql` 与 `sql/02_insert_data.sql` 未改动，14 张基础业务表的数据口径不变。

### 9.3 修订后验收结果

- [x] 2026-10-01 在 `localhost\SQLEXPRESS` 分别以 `TokenHubDB_v01_A`、`TokenHubDB_v01_B`、`TokenHubDB_v01_C` 从空库完整执行 `tools/run_v01.ps1`，三次全部 PASS，退出码 0。
- [x] Q01～Q12、C01～C14、R01～R17、VFY01～VFY11 全部通过，见 `result/run_A/`～`result/run_C/` 的 `query.sql.log`、`constraint.sql.log`、`role.sql.log`、`verify.sql.log`。
- [x] 三个数据库的 `signature.txt` 逐字节一致，证明脚本确定性可复现。
- [x] 低库存账号 2 个，`v_InventoryStatus` 的 `stock_state='low'` 与基表推导结果一致（VFY03）。
- [x] 修订后新增用例截图已补：`result/screenshots/13`～`22` 共 10 张，覆盖 R14～R17、`v_InventoryStatus` 三字段口径、Q09～Q12、C12～C14、VFY01～VFY11 和 A/B/C 三库签名对照；对应 SQL 与原始输出为 `result/evidence_sql/13`～`22` 与 `result/evidence_logs/13`～`22`。
- [ ] 第二名成员独立复现仍未登记。

### 9.4 文档位置变更

| 原位置 | 现位置 |
|---|---|
| `week4/stage_report.md` | `report/stage_report.md` |
| `week4/role_workflow.md` | `report/role_workflow.md` |
| `week4/ai_usage_log.md`（第四周部分） | 并入根 `ai_usage_log.md` 第 4～6 节 |
| `week4/team_division.md`（第四周部分） | 并入根 `team_division.md` |
| `docs/superpowers/plans/2026-09-30-week4-v01.md` | `week4/week4_plan.md`（本文件） |

`week1 & 2/`、`week3/`、`week4/` 保留为过程材料，不属于提交目录；提交目录结构见根 `README.md` 第 9 节。